function sales() {

 window.location.replace("/pentaho/api/repos/%3Ahome%3ASales%3AOps%20Dashboard1%3AproductSales.wcdf/generatedContent");
}


var doc = $(document),
    productSales = {};
    
    

/***************************************************************************
 *                      MISC functions && settings                         *
 ***************************************************************************/ 

doc.ready(function() {
    // Add tooltips to elements that are not implemented in this demo
    $('.analysisColumn:not(.active)').attr("title", "").addClass('analysisTipsyInfo');
    $('.analysisTipsyInfo').tipsy({
        html: true, 
        opacity: 1, 
        fade: true,
        gravity: 'w'
    }); 
    
    // Convert .tipsyInfo elements tooltip in tipsy tooltips
    $('.tipsyInfo').tipsy({
        html: true, 
        opacity: 1, 
        fade: true,
        offset: 5,
        gravity: 'e'
    });
    
    // Add Pentaho logged in user name to .userName element
    $('.userName').text(Dashboards.context["user"]);
});

productSales.addSpaces = function(nStr) {
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ' ' + '$2');
    }
    x2 = x2.slice(0,3);
    return x1 + x2;
};

productSales.formatDate = function(date) {
    var shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        d = date.getDate(),
        m = date.getMonth(),
        M = shortMonths[m];
        
    return M + " " + d;
}

 
/***************************************************************************
*                             Chart Defaults                               *
 ***************************************************************************/  
 
productSales.defaultSettings = function() {
    
    var cd = this.chartDefinition;
    
    // general settings
    cd.height = 250;
    cd.colors = ['#343e47', '#005ca7'];
    cd.plotFrameVisible = false;
    cd.margins = "0 0 0 0";
    
    //legend
    cd.legend = true;
    cd.legendPosition = "top";
    cd.legendAlign = "right";
    cd.legendFont = 'lighter 14px "Open Sans"';
    cd.legendLabel_textStyle = '#343e47';
    cd.legendItemPadding = 10;
    cd.legendClickMode = "toggleVisible";
    
    //tooltips
    cd.tooltipDelayIn = 20;
    cd.tooltipDelayOut = 20;
    cd.tooltipFade = false;
    cd.tooltipGravity = 's';
    cd.tooltipUseCorners  = true;
    cd.tooltipOpacity = 1;
    cd.tooltipFormat = function f(){
        var series = this.getSeriesLabel(),
            category = this.getCategory(),
            value = productSales.addSpaces(this.getValue().toFixed(0)),
            date = productSales.formatDate(category);
        
        return "<div class='tooltipContainer grossProfitTooltip year" + series + "'>" +
            "<div class='tooltipTitle'>" + date + "</div>" +  
            "<div class='tooltipLabel'>" + series + "</div>" +  
            "<div class='tooltipValue'>" + value + "</div>" + 
        "</div>";
    }
    
    // dots
    cd.dotsVisible = true;
    cd.dot_fillStyle = "#FFF";
    cd.dot_shapeRadius = 3;
    
    // lines
    cd.line_lineWidth = 2;
    
    // areas
    cd.areasVisible = true;
    cd.area_fillStyle = function() { return this.finished(this.delegate().alpha(0.5)); }
    
    // axis grids
    cd.baseAxisGrid = true;
    cd.orthoAxisGrid = true;
    cd.baseAxisGrid_strokeStyle = '#eaeaea';
    cd.orthoAxisGrid_strokeStyle = '#eaeaea';
    
    // axis rules
    cd.baseAxisRule_strokeStyle = '#343e47';
    cd.orthoAxisRule_strokeStyle = 'transparent';
    cd.orthoAxisDesiredTickCount = 3;
    cd.orthoAxisTicks_width = 10;
    cd.baseAxisTicks_width = 1;
    cd.orthoAxisTicks_strokeStyle = function() {
        
        // change the color of the first tick
        if(this.index === 0) {
            return "#343e47";
        } else {
            return "#eaeaea";
        }
        
    };
    cd.orthoAxisMinorTicks = false;
    cd.baseAxisMinorTicks = false;
    cd.axisLabel_textStyle = "#676767";
    cd.axisLabel_font = "10px Open Sans";
    cd.baseAxisScale_dateTickFormat = "%b %d";
    cd.baseAxisScale_dateTickPrecision = pvc.time.intervals.d;
    cd.orthoAxisLabel_text = function(scene){ 
        return productSales.addSpaces(this.scene.vars.tick.value);
    };    
    cd.baseAxisLabel_textAlign = function() {
        if(this.index === 0) {
            return "left";
        }
        if(this.index === this.scene.parent.childNodes.length - 1) {
            return "right";
        }
        return "center";
    }
    
    
    cd.dimensions = {
        series: {
            formatter: function(v) {
                if(v == null) { return v; }
                switch(v) {
                    case 'value1': return "2013";
                    case 'value2': return "2014";
                }
                return String(v);
            }
        }
    };
    
}


