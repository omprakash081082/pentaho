
function calls() {

 window.location.replace("/pentaho/api/repos/%3Ahome%3ACallsDashboard%3Acalls%3Acalls.wcdf/generatedContent");
}





var doc = $(document),
    productSales = {};
    
    

/***************************************************************************
 *                      MISC functions && settings                         *
 ***************************************************************************/ 

doc.ready(function() {
    
    $('#teamwiseSalesTable').dataTable( {
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                } );
 
           
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 4 ).footer() ).html(
                '$'+pageTotal +' ( $'+ total +' total)'
            );
        }
    } );
    
    // Add tooltips to elements that are not implemented in this demo
    $('.analysisColumn:not(.active)').attr("title", "<div class='warningMsg'>Not available in this demo.</div>").addClass('analysisTipsyInfo');
    $('.analysisTipsyInfo').tipsy({
        html: true, 
        opacity: 1, 
        fade: true,
        gravity: 'w'
    });
    
    // Convert .tipsyInfo elements tooltip in tipsy tooltips
    $('.tipsyInfo').tipsy({
        html: true, 
        opacity: 1, 
        fade: true,
        offset: 5,
        gravity: 'e'
    });
    
    // Add Pentaho logged in user name to .userName element
    $('.userName').text(Dashboards.context["user"]);
});

productSales.addSpaces = function(nStr) {
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ' ' + '$2');
    }
    x2 = x2.slice(0,3);
    return x1 + x2;
};

productSales.formatDate = function(date) {
    var shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        d = date.getDate(),
        m = date.getMonth(),
        M = shortMonths[m];
        
    return M + " " + d;
}

 
/***************************************************************************
*                             Chart Defaults                               *
 ***************************************************************************/  
 



